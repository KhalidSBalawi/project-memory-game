/*
 * Create a list that holds all of your cards
 */
// globle varebal
let toggleCards = [];
let moves = 0;
let time = 0;
let timerOff = true;
let timer;
let matched = 0;
/*
 * Display the cards on the page
 *   - shuffle the list of cards using the provided "shuffle" method below
 *   - loop through each card and create its HTML
 *   - add each card's HTML to the page
 */

// Shuffle function from http://stackoverflow.com/a/2450976
function shuffle(array) {
    var currentIndex = array.length, temporaryValue, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
}


/*
 * set up the event listener for a card. If a card is clicked:
 *  - display the card's symbol (put this functionality in another function that you call from this one)
 *  - add the card to a *list* of "open" cards (put this functionality in another function that you call from this one)
 *  - if the list already has another card, check to see if the two cards match
 *    + if the cards do match, lock the cards in the open position (put this functionality in another function that you call from this one)
 *    + if the cards do not match, remove the cards from the list and hide the card's symbol (put this functionality in another function that you call from this one)
 *    + increment the move counter and display it on the page (put this functionality in another function that you call from this one)
 *    + if all cards have matched, display a message with the final score (put this functionality in another function that you call from this one)
 */

// adding selector to deck
let deck = document.querySelector('.deck');

// adding event listner to card if clciked
deck.addEventListener('click', function () {
    let clickTarget = event.target;

    if (clickTarget.classList.contains('card') && toggleCards.length < 2 && !toggleCards.includes(clickTarget)) {
        toggleCard(clickTarget);
        addToggleCard(clickTarget);
        if (timerOff) {
            timerStart();
            timerOff = false;
        }
        if (toggleCards.length == 2) {
            matchCeck(clickTarget);
            movesCounter();
            movesCheck();
        }

    }
});

// flipping over card
function toggleCard(clickTarget) {
    clickTarget.classList.toggle('open');
    clickTarget.classList.toggle('show');
}

// adding open card to arry
function addToggleCard(clickTarget) {
    toggleCards.push(clickTarget);

}

// checking if 2 cards match
function matchCeck() {
    if (toggleCards[0].firstElementChild.className == toggleCards[1].firstElementChild.className) {
        toggleCards[0].classList.toggle('match');
        toggleCards[1].classList.toggle('match');
        toggleCards = [];
        matched++;
        if (matched === 8) {
            gameOver();
        }

    }
    else {
        setTimeout(function () {
            toggleCard(toggleCards[0]);
            toggleCard(toggleCards[1]);
            toggleCards = [];
        }, 1000);
    }
}

//moves counter
function movesCounter() {
    moves++;
    let move = document.querySelector('.moves');
    move.innerHTML = moves;
}

//
function movesCheck() {
    if (moves === 8 || moves === 16) {
        removeStar();
    }
}

// stars rating
function removeStar() {
    const starList = document.querySelectorAll('.stars li');
    for (star of starList) {
        if (star.style.display !== 'none') {
            star.style.display = 'none';
            break;
        }
    }
}

//starting the game timer
function timerStart() {
    timer = setInterval(function () {
        time++;
        timeDisply();
    }, 1000);
}

//display the time 
function timeDisply() {
    const minute = Math.floor(time / 60);
    const second = time % 60;
    let timeShow = document.querySelector('.time')
    timeShow.innerHTML = time;
    if (second < 10) {
        timeShow.innerHTML = `${minute}:0${second}`;
    } else {
        timeShow.innerHTML = `${minute}:${second}`;
    }

};

//stop timer
function timerStop() {
    clearInterval(timer);
}
//modal
function toggleModal() {
    const modal = document.querySelector('.modal-background');
    modal.classList.toggle('hide');
}

//modal stats
function modalStats() {
    let statsTime = document.querySelector('.modal-time');
    let finalTime = document.querySelector('.time').innerHTML;
    let statsMove = document.querySelector('.modal-moves');
    let statsStars = document.querySelector('.modal-stars');
    let stars = starsCount();

    statsTime.innerHTML = `Time = ${finalTime}`;
    statsMove.innerHTML = `Moves = ${moves}`;
    statsStars.innerHTML = `Stars = ${stars}`;
}

// Star count
function starsCount() {
    stars = document.querySelectorAll('.stars li');
    starsCount = 0;
    for (star of stars) {
        if (star.style.display !== 'none') {
            starsCount++;
        }
    }
    return starsCount;
}


//Game over
function gameOver() {
    timerStop();
    modalStats();
    toggleModal();
}

// reset the game
function resetGame() {
    toggleCards =[]
    timerStop();
    timerOff = true;
    time = 0;
    timeDisply();
    moves = 0;
    resetCard();
    document.querySelector('.moves').innerHTML = moves;
    stars = 0;
    let starList = document.querySelectorAll('.stars li');
    for (star of starList) {
        star.style.display = 'inline';
    }
}

// restart, replay buttons
document.querySelector('.restart').addEventListener('click', resetGame);

document.querySelector('.replay').addEventListener('click', function () {
    resetGame();
    toggleModal();
});

// resst Cards
function resetCard() {
    let cards = document.querySelectorAll('.deck li');
    for (let card of cards) {
        card.className = 'card';
    }
}