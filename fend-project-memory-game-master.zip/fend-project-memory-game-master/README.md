# Memory Game Project
part from Udacity FEND.


## Game Ruls

The game board consists of sixteen "cards" arranged in a grid. The deck is made up of eight different pairs of cards, each with different symbols on one side. The cards are arranged randomly on the grid with the symbol face down. The gameplay rules are very simple: flip over two hidden cards at a time to locate the ones that match!


## How to Open the Game

open index.html via any web browser.


## How to Play

 click on card to flip it over, the goal is matching tow cards contine same symbol.

 
## Dependencies

HTML, CSS, JavaScript, Bootstrap and Google Font API.
